const KEY = "lab8_kanban";
const STATUSES = ["plan", "work", "done"];

const form = document.querySelector("#form");
const titleInput = document.querySelector("#title");
const errorEl = document.querySelector("#error");
const columns = {};
document.querySelectorAll(".col").forEach(col => {
  columns[col.dataset.status] = {
    list: col.querySelector("ul"),
    count: col.querySelector(".count")
  };
});

let cards = loadCards();

// проверка, что объект похож на карточку
function isCard(c) {
  return c && typeof c.title === "string" && STATUSES.includes(c.status);
}

function loadCards() {
  try {
    const data = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(data) ? data.filter(isCard) : [];
  } catch (e) {
    console.warn("Данные доски повреждены, доска очищена");
    return [];
  }
}

function save() {
  localStorage.setItem(KEY, JSON.stringify(cards));
  render();
}

function moveCard(card, step) {
  const i = STATUSES.indexOf(card.status) + step;
  if (i < 0 || i >= STATUSES.length) return;
  card.status = STATUSES[i];
  save();
}

function makeButton(text, onClick, disabled, cls) {
  const b = document.createElement("button");
  b.type = "button";
  b.textContent = text;
  b.disabled = disabled;
  if (cls) b.className = cls;
  b.addEventListener("click", onClick);
  return b;
}

function render() {
  STATUSES.forEach(s => columns[s].list.replaceChildren());

  cards.forEach(card => {
    const li = document.createElement("li");
    const p = document.createElement("p");
    p.textContent = card.title;

    const actions = document.createElement("div");
    actions.className = "actions";
    const pos = STATUSES.indexOf(card.status);
    actions.append(
      makeButton("←", () => moveCard(card, -1), pos === 0),
      makeButton("→", () => moveCard(card, 1), pos === STATUSES.length - 1),
      makeButton("Удалить", () => {
        cards = cards.filter(c => c !== card);
        save();
      }, false, "del")
    );

    li.append(p, actions);
    columns[card.status].list.append(li);
  });

  STATUSES.forEach(s => {
    const n = cards.filter(c => c.status === s).length;
    columns[s].count.textContent = "(" + n + ")";
  });
}

form.addEventListener("submit", e => {
  e.preventDefault();
  const title = titleInput.value.trim();
  if (!title) {
    errorEl.textContent = "Название карточки не может быть пустым";
    errorEl.hidden = false;
    return;
  }
  errorEl.hidden = true;
  cards.push({ id: Date.now(), title: title, status: "plan" });
  titleInput.value = "";
  save();
});

// ---- дополнительное задание: экспорт / импорт ----
document.querySelector("#export").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(cards, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "kanban.json";
  a.click();
  URL.revokeObjectURL(a.href);
});

document.querySelector("#import").addEventListener("change", e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if (!Array.isArray(data)) throw new Error("ожидался массив");
      cards = data.filter(isCard);
      save();
      errorEl.hidden = true;
    } catch (err) {
      errorEl.textContent = "Не удалось прочитать файл: это не корректный JSON доски";
      errorEl.hidden = false;
    }
    e.target.value = "";
  };
  reader.readAsText(file);
});

document.querySelector("#reset").addEventListener("click", () => {
  if (!confirm("Удалить все карточки?")) return;
  cards = [];
  localStorage.removeItem(KEY);
  render();
});

render();
