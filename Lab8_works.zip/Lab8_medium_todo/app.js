const KEY = "lab8_todo";

const form = document.querySelector("#form");
const taskInput = document.querySelector("#task");
const errorEl = document.querySelector("#error");
const listEl = document.querySelector("#list");
const emptyEl = document.querySelector("#empty");
const counterEl = document.querySelector("#counter");
const filterBtns = document.querySelectorAll("[data-filter]");

let tasks = loadTasks();
let filter = "all";

function loadTasks() {
  try {
    const data = JSON.parse(localStorage.getItem(KEY) || "[]");
    if (!Array.isArray(data)) return [];
    // оставляем только нормальные объекты задач
    return data.filter(t => t && typeof t.text === "string" && typeof t.id !== "undefined")
               .map(t => ({ id: t.id, text: t.text, done: Boolean(t.done) }));
  } catch (e) {
    console.warn("JSON в хранилище сломан, список сброшен");
    return [];
  }
}

function save() {
  localStorage.setItem(KEY, JSON.stringify(tasks));
  render();
}

function render() {
  listEl.replaceChildren();

  const shown = tasks.filter(t =>
    filter === "all" ? true : filter === "done" ? t.done : !t.done
  );

  shown.forEach(task => {
    const li = document.createElement("li");
    if (task.done) li.classList.add("done");

    const check = document.createElement("input");
    check.type = "checkbox";
    check.checked = task.done;
    check.addEventListener("change", () => {
      task.done = check.checked;
      save();
    });

    const span = document.createElement("span");
    span.textContent = task.text;

    const del = document.createElement("button");
    del.textContent = "Удалить";
    del.addEventListener("click", () => {
      tasks = tasks.filter(t => t.id !== task.id);
      save();
    });

    li.append(check, span, del);
    listEl.append(li);
  });

  emptyEl.hidden = shown.length > 0;
  const left = tasks.filter(t => !t.done).length;
  counterEl.textContent = tasks.length
    ? "Осталось выполнить: " + left + " из " + tasks.length
    : "";
}

form.addEventListener("submit", e => {
  e.preventDefault();
  const text = taskInput.value.trim();
  if (!text) {
    errorEl.textContent = "Введите текст задачи";
    errorEl.hidden = false;
    return;
  }
  errorEl.hidden = true;
  tasks.push({ id: Date.now(), text: text, done: false });
  taskInput.value = "";
  save();
});

filterBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    filter = btn.dataset.filter;
    filterBtns.forEach(b => b.classList.toggle("active", b === btn));
    render();
  });
});

render();
