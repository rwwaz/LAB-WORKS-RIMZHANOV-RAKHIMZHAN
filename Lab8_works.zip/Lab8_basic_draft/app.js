const KEY = "lab8_draft";

const toInput = document.querySelector("#to");
const textInput = document.querySelector("#text");
const status = document.querySelector("#status");
const clearBtn = document.querySelector("#clear");

// читаем черновик; если там мусор или ничего нет - возвращаем пустой
function loadDraft() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { to: "", text: "", time: null };
    const data = JSON.parse(raw);
    if (typeof data !== "object" || data === null) throw new Error("bad format");
    return {
      to: String(data.to ?? ""),
      text: String(data.text ?? ""),
      time: data.time ?? null
    };
  } catch (e) {
    console.warn("Черновик повреждён, начинаем с чистого:", e.message);
    localStorage.removeItem(KEY);
    return { to: "", text: "", time: null };
  }
}

function showStatus(time) {
  status.textContent = time
    ? "Сохранено в " + new Date(time).toLocaleTimeString("ru-RU")
    : "Черновика пока нет";
}

function saveDraft() {
  // пустой черновик не храним
  if (!toInput.value.trim() && !textInput.value.trim()) {
    localStorage.removeItem(KEY);
    showStatus(null);
    return;
  }
  const draft = {
    to: toInput.value,
    text: textInput.value,
    time: Date.now()
  };
  localStorage.setItem(KEY, JSON.stringify(draft));
  showStatus(draft.time);
}

// небольшая задержка, чтобы не писать в хранилище на каждую букву
let timer;
function onType() {
  clearTimeout(timer);
  status.textContent = "Печатаете...";
  timer = setTimeout(saveDraft, 400);
}

toInput.addEventListener("input", onType);
textInput.addEventListener("input", onType);

clearBtn.addEventListener("click", () => {
  localStorage.removeItem(KEY);
  toInput.value = "";
  textInput.value = "";
  showStatus(null);
});

const draft = loadDraft();
toInput.value = draft.to;
textInput.value = draft.text;
showStatus(draft.time);
